﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//실행부Main 파일
namespace PoketMonsterGame
{
    class Program
    {
    static void Main(string[] args)
        {
            PoketMonGame GameStart = new PoketMonGame();
            GameStart.PoketMon();
        }
    }
}
