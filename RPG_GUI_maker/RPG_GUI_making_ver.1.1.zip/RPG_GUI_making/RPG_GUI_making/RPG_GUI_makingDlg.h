﻿
// RPG_GUI_makingDlg.h: 헤더 파일
//

#pragma once
class user
{
public:
	CString name;
	CString _class;
	int hp, mp, power, magic, shild;
	user()
	{
		hp = 10, mp = 10, power = 10, magic = 10, shild = 10;
	}
};

// CRPGGUImakingDlg 대화 상자
class CRPGGUImakingDlg : public CDialogEx
{
// 생성입니다.
public:
	CRPGGUImakingDlg(CWnd* pParent = nullptr);	// 표준 생성자입니다.
	int spin_value_HP;
	int spin_value_MP;
	int spin_value_POWER;
	int spin_value_MAGIC;
	int spin_value_SHILD;
// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_RPG_GUI_MAKING_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 지원입니다.


// 구현입니다.
protected:
	HICON m_hIcon;

	// 생성된 메시지 맵 함수
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	user player;
	afx_msg void OnEnChangeEdit4();
	afx_msg void OnEnChangeEdit3();
	afx_msg void OnEnChangeEdit2();
	afx_msg void OnEnChangeEdit5();
	afx_msg void OnEnChangeEdit6();
	afx_msg void OnDeltaposSpin6(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpin1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpin2(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpin3(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpin4(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpin5(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnCbnSelchangeCombo1();
	afx_msg void OnEnChangeEdit1();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	CEdit mEdit;
	CComboBox m_Combo;
	CEdit m_hp;
	afx_msg void OnEnChangeEditSpin();
};
